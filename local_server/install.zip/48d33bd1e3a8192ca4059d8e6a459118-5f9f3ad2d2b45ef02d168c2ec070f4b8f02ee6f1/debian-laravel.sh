# ================================================
# PHP 7.2
#
# See https://www.colinodell.com/blog/201711/installing-php-72
# ================================================
apt-get install -y apt-transport-https lsb-release ca-certificates
wget -O /etc/apt/trusted.gpg.d/php.gpg https://packages.sury.org/php/apt.gpg
echo "deb https://packages.sury.org/php/ $(lsb_release -sc) main" | tee /etc/apt/sources.list.d/php.list
apt-get update
apt-get install -y php7.2-cli php7.2-gd php7.2-mbstring php7.2-curl php7.2-xml php7.2-zip

# Check what user PHP-FPM is running as (it's www-data)
ps aux | grep php


# ================================================
# MongoDB
#
# Documentation: https://docs.mongodb.com/
# ================================================
apt-get install php7.2-mongodb

# Check mongodb extension is enabled
php --ini

# ...
# /etc/php/7.2/cli/conf.d/30-mongodb.ini

apt-get install mongodb-server

# Test if MongoDB is working properly
netstat -ln | grep 27017 
# tcp        0      0 127.0.0.1:27017         0.0.0.0:*               LISTEN

# ================================================
# Nginx
#
# See https://laravel.com/docs/5.6/deployment
# Documentation: https://nginx.ru/en/docs/
# ================================================
apt-get install -y nginx php7.2-fpm
systemctl stop nginx.service 
systemctl stop php7.2-fpm.service

# use config from file nginx-host.conf
nano /etc/nginx/sites-available/default

systemctl start nginx.service 
systemctl start php7.2-fpm.service

# Test if Ngixn is working properly
netstat -ln | grep 80 
# tcp        0      0 0.0.0.0:80              0.0.0.0:*               LISTEN


# ================================================
# MySQL
#
# Documentation: https://dev.mysql.com/doc/
# ================================================
apt-get install -y mysql-server php7.2-mysql
mysql
# Create new database and user from file mysql.conf

# Test if MySQL is working properly
netstat -ln | grep 3306 
# tcp   0      0 127.0.0.1:3306          0.0.0.0:*               LISTEN 


# ================================================
# Redis
#
# Documentation: https://redis.io/documentation
# ================================================
apt-get install -y build-essential tcl software-properties-common

# From redis PPA repository
#
# See https://linode.com/docs/databases/redis/how-to-install-a-redis-server-on-ubuntu-or-debian8/
add-apt-repository ppa:chris-lea/redis-server
wget https://www.dotdeb.org/dotdeb.gpg
apt-key add dotdeb.gpg
apt-get update
apt-get install redis-server

# From sources
#
# See https://www.hugeserver.com/kb/install-redis-4-debian-9-stretch/
wget http://download.redis.io/releases/redis-stable.tar.gz
tar xvzf redis-stable.tar.gz
cd redis-stable/
make && make install
make test
cd utils/
bash install_server.sh
systemctl start redis_6379
systemctl enable redis_6379

# Test if Redis is working properly
netstat -ln | grep 6379 
# tcp        0      0 127.0.0.1:6379          0.0.0.0:*               LISTEN

cd ../../
rm redis-stable -Rf
rm redis-stable.tar.gz

# Note:
# Use Horizon to queues monitor
# https://laravel.com/docs/5.6/horizon


# ================================================
# Composer
#
# See https://getcomposer.org/doc/00-intro.md#installation-linux-unix-osx
# Documentation: https://getcomposer.org/doc/
# ================================================
curl -sS https://getcomposer.org/installer | php
mv composer.phar /usr/local/bin/composer
chmod +x /usr/local/bin/composer

# ================================================
# Laravel
#
# See https://laravel.com/docs/5.6/installation
# See https://laravel.com/docs/5.6/filesystem#the-public-disk
# Documentation: https://laravel.com/docs/
# ================================================
apt-get install -y git

# Clone your project into /var/www
git clone ... /var/www

# Change folders permissons
chown -R www-data.www-data /var/www
chmod -R 755 /var/www
chmod -R 777 /var/www/storage

cd /var/www

# Install packages via composer
composer install

cp .env.example .env
php artisan key:generate

php artisan storage:link

# Note:
# Use Envoy to run tasks you run on your remote servers.
# https://laravel.com/docs/5.6/envoy
#
# Use Deployer to deployment your laravel application
# https://deployer.org/


# ================================================
# Supervisor
#
# See https://laravel.com/docs/5.6/queues#supervisor-configuration
# Documentation: http://supervisord.org/
# ================================================
apt-get install -y supervisor
touch /etc/supervisor/conf.d/laravel-worker.conf

# use config from file laravel-worker.conf
nano /etc/supervisor/conf.d/laravel-worker.conf

supervisorctl reread
supervisorctl update
supervisorctl start laravel-worker:*


# ================================================
# Websocket server (Echo server)
#
# See https://github.com/tlaverdure/laravel-echo-server
# ================================================
curl -sL https://deb.nodesource.com/setup_9.x | sudo -E bash -
apt-get install -y nodejs
npm install -g laravel-echo-server

cd /var/www
laravel-echo-server init

# use config from file websocket-worker.conf
nano /etc/supervisor/conf.d/websocket-worker.conf

supervisorctl reread
supervisorctl update
supervisorctl start websocket:*

# Test if Websocket server is working properly
netstat -ln | grep 6001 
# tcp6       0      0 :::6001                 :::*                    LISTEN

# ================================================
# Crontab
#
# See https://laravel.com/docs/5.6/scheduling#introduction
# ================================================
crontab -e

# Append new line
# * * * * * php /var/www/artisan schedule:run >> /var/www/storage/logs/cron.log 2>&1


# ================================================
# Key based authentication
#
# See https://www.digitalocean.com/community/tutorials/how-to-configure-ssh-key-based-authentication-on-a-linux-server
# ================================================
ssh-keygen
touch ~/.ssh/authorized_keys
cat ~/.ssh/id_rsa.pub >> ~/.ssh/authorized_keys

ssh-copy-id username@remote_host # Example root@127.0.0.1
ssh sername@remote_host
nano /etc/ssh/sshd_config
# PasswordAuthentication no

systemctl restart ssh

# Clean apt
apt-get clean

# ================================================
# Change timezone
# ================================================
dpkg-reconfigure tzdata

# ======================================================
# Useful links
# ======================================================
#
# https://tecadmin.net/install-laravel-framework-on-ubuntu/
# https://linuxconfig.org/how-to-install-a-lamp-server-on-debian-9-stretch-linux
# https://gist.github.com/santoshachari/87bf77baeb45a65eb83b553aceb135a3
# https://serversforhackers.com/c/lemp-nginx-php-laravel
# https://deployer.org/
# https://laravel.com/docs/5.6/envoy
# https://github.com/Neilpang/acme.sh
# https://sonikelf.ru/pervichnaya-nastrojka-iptables-dlya-veb-servera-na-primere-centos/