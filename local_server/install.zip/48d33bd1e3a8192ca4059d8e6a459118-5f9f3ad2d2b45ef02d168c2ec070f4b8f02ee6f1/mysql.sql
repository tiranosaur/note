CREATE DATABASE homestead;
GRANT ALL ON homestead.* to 'homestead'@'localhost' IDENTIFIED BY 'secret';
FLUSH PRIVILEGES;