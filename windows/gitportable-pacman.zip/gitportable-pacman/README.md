# gitportable-pacman

Script to install pacman in git for Windows portable

Run `sh install-pacman-git-bash.sh` from a git-bash session.

Install additional packages `Pacman -Syu zip`

Install additional packages `Pacman -Syu rsync`
